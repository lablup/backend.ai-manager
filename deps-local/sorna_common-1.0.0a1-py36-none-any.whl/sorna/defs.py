# Redis database IDs depending on purposes
SORNA_KERNEL_DB   = 1
SORNA_INSTANCE_DB = 2
SORNA_SESSION_DB  = 3
SORNA_RLIM_DB     = 4
