#! /usr/bin/env python3

from .serialize import Message

__all__ = ['Message']
