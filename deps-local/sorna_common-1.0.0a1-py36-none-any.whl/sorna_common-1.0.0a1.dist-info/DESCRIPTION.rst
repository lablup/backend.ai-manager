sorna-common
============

|PyPI version| |Python Versions| |Build Status| |Code Coverage|

Common libraries and utilities for Sorna

Installation
------------

.. code:: sh

    pip install sorna-common

For development
~~~~~~~~~~~~~~~

.. code:: sh

    pip install -r requirements-dev.txt

.. |PyPI version| image:: https://badge.fury.io/py/sorna-common.svg
   :target: https://badge.fury.io/py/sorna-common
.. |Python Versions| image:: https://img.shields.io/pypi/pyversions/sorna-common.svg
   :target: https://pypi.org/project/sorna-common/
.. |Build Status| image:: https://travis-ci.org/lablup/sorna-common.svg?branch=master
   :target: https://travis-ci.org/lablup/sorna-common
.. |Code Coverage| image:: https://codecov.io/gh/lablup/sorna-common/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/lablup/sorna-common


